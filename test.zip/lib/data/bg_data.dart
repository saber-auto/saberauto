/// List of Background Images////
List<String> bgList = [
  "bg1.jpeg",
  "bg2.jpeg",
  "bg3.jpeg",
  "bg4.webp",
  "bg5.jpeg",
  "bg6.jpeg",
  "bg7.jpg",
  "bg8.jpeg",
];
